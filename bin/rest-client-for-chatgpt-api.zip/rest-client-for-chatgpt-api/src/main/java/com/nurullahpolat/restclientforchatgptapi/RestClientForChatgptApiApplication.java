package com.nurullahpolat.restclientforchatgptapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestClientForChatgptApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestClientForChatgptApiApplication.class, args);
	}

}
