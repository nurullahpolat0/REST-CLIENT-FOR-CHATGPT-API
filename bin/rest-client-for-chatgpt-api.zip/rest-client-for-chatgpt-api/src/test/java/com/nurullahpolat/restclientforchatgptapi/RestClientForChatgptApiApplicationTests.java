package com.nurullahpolat.restclientforchatgptapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestClientForChatgptApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
